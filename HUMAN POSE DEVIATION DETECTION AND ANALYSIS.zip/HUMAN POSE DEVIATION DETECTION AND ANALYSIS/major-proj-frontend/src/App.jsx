import { useState } from "react";
import axios from "axios";
import "./App.css"; // Import CSS file

function App() {
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileName, setFileName] = useState("");
  const [processedImage, setProcessedImage] = useState(null);
  const [prediction, setPrediction] = useState(null);
  const [analysis, setAnalysis] = useState(null);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
    setFileName(file ? file.name : "");
  };

  const handleUpload = async () => {
    if (!selectedFile) return;

    const formData = new FormData();
    formData.append("file", selectedFile);

    try {
      const response = await axios.post("http://127.0.0.1:5000/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setProcessedImage(`data:image/jpeg;base64,${response.data.image}`);
      setAnalysis(response.data.analysis);
      setPrediction(response.data.prediction);
      alert(`PREDICTED POSE: ${response.data.prediction}`);
    } catch (error) {
      console.error("Error uploading file", error);
    }
  };

  return (
    <div className="app-container">
      <h1 className="text-3xl font-bold mb-6 text-blue-800">PosePerfect </h1>

      {/* File Upload */}
      <input type="file" accept="image/*" onChange={handleFileChange} className="file-input" />

      {fileName && <p className="text-gray-700 mb-4">Selected File: <strong>{fileName}</strong></p>}

      <button onClick={handleUpload} className="upload-btn">Analyze Pose</button>

      {processedImage && (
  <div className="result-container">
    <img src={processedImage} alt="Processed" className="processed-image" />

    {/* Analysis Results */}
    {analysis && (
      <div className="analysis-container">
        <h2>Analysis Results</h2>
        <p className="text-gray-800 font-semibold mt-2">
        <span ><b>Predicted Class</b></span> {prediction} </p>
        <p><strong>Right Knee:</strong> {analysis.right_knee}</p>
        <p><strong>Left Knee:</strong> {analysis.left_knee}</p>
        <p><strong>Right Shoulder:</strong> {analysis.right_shoulder}</p>
        <p><strong>Left Shoulder:</strong> {analysis.left_shoulder}</p>
        <h2 className="motivation-text">Align your posture with the angle analysis provided above!</h2>
        <h3 className="motivation-text">Keep pushing towards PERFECTION! 😊</h3>
      </div>
    )}
  </div>
)}

    </div>
  );
}

export default App;
